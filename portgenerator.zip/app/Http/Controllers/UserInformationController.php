<?php

namespace App\Http\Controllers;

use App\Models\UserInformation;
use Illuminate\Http\Request;

class UserInformationController extends Controller
{
    // Display a listing of the user information
    public function index()
    {
        $userInformation = UserInformation::all();
        return response()->json($userInformation);
    }

    // Show the form for creating a new user information
    public function create()
    {
        return view('user_information.create');
    }

    // Store a newly created user information in storage
    public function store(Request $request)
    {
        $validated = $request->validate([
            'fullname' => 'required|string|max:255',
            'user_id' => 'required|integer',
        ]);

        $userInformation = UserInformation::create($validated);
        return response()->json($userInformation, 201);
    }

    // Display the specified user information
    public function show($id)
    {
        $userInformation = UserInformation::findOrFail($id);
        return response()->json($userInformation);
    }

    // Show the form for editing the specified user information
    public function edit($id)
    {
        $userInformation = UserInformation::findOrFail($id);
        return view('user_information.edit', compact('userInformation'));
    }

    // Update the specified user information in storage
    public function update(Request $request, $id)
    {
        $validated = $request->validate([
            'fullname' => 'required|string|max:255',
            'user_id' => 'required|integer',
        ]);

        $userInformation = UserInformation::findOrFail($id);
        $userInformation->update($validated);
        return response()->json($userInformation);
    }

    // Remove the specified user information from storage
    public function destroy($id)
    {
        $userInformation = UserInformation::findOrFail($id);
        $userInformation->delete();
        return response()->json(null, 204);
    }
}
